style_terminal = 'color(8)'
